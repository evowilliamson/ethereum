const HackerOne = artifacts.require("./HackerOne.sol");
const HackerTwo = artifacts.require("./HackerTwo.sol");
const Splitter = artifacts.require("./Splitter.sol");

module.exports = (deployer) => {}
        
    