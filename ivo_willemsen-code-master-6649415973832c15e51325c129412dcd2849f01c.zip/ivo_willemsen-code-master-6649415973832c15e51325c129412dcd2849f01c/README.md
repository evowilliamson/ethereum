# Electronic Toll System

This repository contains the smart contracts, web application and test cases that pertain to the implementation of an electronic toll system by using a Ethereum blockchain.

## Architecture
The following component diagram depicts the architecture of the system

![alt text](ComponentModel-ElectronicTollSystem.png)


An off-chain data store (PouchDB) is used to:

* Translate blockchain addresses to meaningful logical names
* Store historical data
* Manage lists of objects which are hard to maintain in a Solidity

The web application will be responsible for keeping the blockchain state and the off-chain data store in-sync

## Deploying the smart contracts
Deploy the smart contracts by issuing the following command in the ```ivo_willemsen-code``` directory:
```
truffle deploy
```

## Installation of the web application
Perform the following instructions to install the application:
  
```
npm install
```

## Running the application
First, bring up ganache:

```
ganache-cli -a 10 -g 15000 -l 150000000000000000 -h 0.0.0.0
```

... then navigate to the following URL:
```
http://localhost:3000
```
... play around!